<?php
  extract($_POST);
  //echo "<pre>";
  //print_r($_POST);

  if(isset($_POST['submit']))
  {
      $bugname = $_POST["bugName"];
      $bugdesc = $_POST["bugDesc"];
      $comment = $_POST["comment"];
      echo $insertion = "insert into reports (reporting_id, bug_name, solution, proj_id, comments, status) VALUES (NULL,'$bugname', '$bugdesc', '$data1', '$comment', '1')";
      require_once("config.php");
      $conn = getPDOConnection();
      //$query = "UPDATE `user` set `proj_id` = '$id' WHERE username = '$username'";
      $data = $conn -> query($insertion);
  }
?>
